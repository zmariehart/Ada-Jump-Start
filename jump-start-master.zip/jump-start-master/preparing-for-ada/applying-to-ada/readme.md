Applicants who have completed this JumpStart curriculum including all the coding exercises, are better prepared for the application process and therefore becoming a new student at Ada Developers Academy.

Learn more about the application process for Ada Developers Academy on [this site](https://www.adadevelopersacademy.org/applicants).
