1.

`puts person.length` : `3`

`puts person["last_name"]` : `"lovelace"`

2.

`puts animals["dog"]` : `"canine"`

`puts animals["donkey"]` : `nil`

3.

`puts chuck_norris["kick"]` : `25`

4.

`puts menu.length` : `3`

`puts menu["burger"]` : `"bleu sun"`

`puts menu["tater_tots"]` : `nil`
